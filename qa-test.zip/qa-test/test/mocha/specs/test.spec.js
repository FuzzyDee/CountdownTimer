require('babel-polyfill');
//require ('babel');
var expect = require('chai').expect


import assert from 'assert';
import Server from '../../../app/server';




describe('App', () => {

  before(() => {
    Server.start(9000);
  });

  // after(() => {
  //   Server.stop();
  // });

  beforeEach(() => {
    browser.url('/');
  });

  it('todo e2e', () => {
    const app = browser.element(`[data-automation='app']`);
    const appVisible = app.isVisible();
    assert.equal(appVisible, true);

    //browser.debug();
    
  });
  describe('Add To-do',()=>{
it ('should add fisrt todo',()=>{
  //browser.debug();

browser.setValue('input[placeholder="add item"]', 'Create Test Script').click
 var value = browser.getValue();
     assert(value === 'sweet'); // true
browser.saveScreenshot('result.png');
});

it ('should add second todo',()=>{
  browser.debug();

browser.setValue('input[placeholder="add item"]', 'Face-face interview').click
// var value = browser.getValue()
//     assert(value === 'sweet') // true
browser.saveScreenshot('result.png');

});
it ('should add third todo',()=>{
  //browser.debug();

browser.setValue('input[placeholder="add item"]', 'Go Lunch').click
// var value = browser.getValue()
//     assert(value === 'sweet') // true
browser.saveScreenshot('result.png');

});
});

it('delete todo',()=>{


});
});
