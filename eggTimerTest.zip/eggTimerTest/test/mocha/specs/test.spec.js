var assert = require('assert');
beforeEach(() => {
    browser.url('/');
  });
  describe('eggTimer Countdown page',function(){
      it('should launch the website and display title',function(){
          //browser.url('/');
          var title=browser.getTitle();
          assert.equal(title,'E.gg Timer - a simple countdown timer');
          browser.saveScreenshot('result.png');
        //   browser.debug();
      });
    });
      describe('Should Countdown in second decreement',function(){
          it('should enter specified number as time',function(){
            var input = $('input[id=start_a_timer]')
            browser.clearElement('input[id=start_a_timer]')
            input.setValue('2 minutes')
            console.log(input.getValue()) // returns '2 minutes'
            var value = browser.getValue('input[id=start_a_timer]');
            assert(value === '2 minutes'); // true
            browser.saveScreenshot('result.png');

          });
          it('should the click the Go command', function () {
            browser.setValue('input[id=start_a_timer]','25 seconds').click('#timergo');
            var myButton = $('#timergo')
           var elem = $('#progressText');
            // elem.waitForText(25000);
            // function elem(seconds){
            //     var seconds = 25;
            // for(int =0;seconds<25;seconds-- );
            // }
           
            //browser.debug();
            browser.waitUntil(function (elem) {
                return browser.getText('#progressText') === 'Time Expired!'
              }, 30000, 'expected text to be different after 25s');
            browser.alertText(['Time Expired!']);
            page.driver.browser.switch_to.alert.accept();
            
    
            
            browser.saveScreenshot('result.png');
           
        });
      });
  
